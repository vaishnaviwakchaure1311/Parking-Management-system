from django.apps import AppConfig


class SourceConfig(AppConfig):
    name = 'source'
