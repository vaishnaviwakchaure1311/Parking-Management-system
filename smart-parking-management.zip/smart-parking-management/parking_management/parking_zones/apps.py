from django.apps import AppConfig


class ParkingZonesConfig(AppConfig):
    name = 'parking_zones'
